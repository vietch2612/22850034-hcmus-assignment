# Return the count of a given substring from a string
# Given str_x = "Emma is good developer. Emma is a writer"
# Return Emma appeared 2 times

string_x = "Emma is good developer. Emma is a writer"
print('Emma appeared ' + str(string_x.count('Emma')) + ' time(s).')