# Exercise 1: Print current date and time in Python


import datetime

print(datetime.datetime.now())
print(datetime.datetime.now().time())