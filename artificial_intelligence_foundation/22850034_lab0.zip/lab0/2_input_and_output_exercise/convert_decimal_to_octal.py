# Given a number
# Print the octual number of that number
# For example, given number is 8, print octal number is 10
number = 8
print('%o' % number)