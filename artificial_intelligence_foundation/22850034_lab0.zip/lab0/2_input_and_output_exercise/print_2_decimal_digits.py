# Display float number with 2 decimal places using
# Given number is 30.123456, print 30.12

float_number = 30.123456
print("%.2f" % float_number)