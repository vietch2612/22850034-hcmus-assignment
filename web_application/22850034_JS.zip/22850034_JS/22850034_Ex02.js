// find the largest number from three numbers
function getLargest(a, b, c) {
    return Math.max(a, b, c);
}

console.log(getLargest(2, 3, 4));
console.log(getLargest(4, 3, 2));
console.log(getLargest(3, 4, 2));
console.log(getLargest(3, 2, 4));
console.log(getLargest(17, 1, 8));
console.log(getLargest(5, 5, 9));
console.log(getLargest(1, 22, 3));
console.log(getLargest(88, 87, 86));
console.log(getLargest(4, 2, 3));
