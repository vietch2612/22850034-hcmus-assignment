export class PaymentSystem {
  processPayment(amount: number): string {
    return `Payment: Payment of $${amount} is paid`;
  }
}
