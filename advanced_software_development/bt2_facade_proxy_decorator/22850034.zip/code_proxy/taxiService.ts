export interface TaxiService {
  bookRide(start: string, end: string): string;
}
