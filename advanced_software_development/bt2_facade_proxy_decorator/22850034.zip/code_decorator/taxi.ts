export interface Taxi {
  calculateCost(): number;
}
